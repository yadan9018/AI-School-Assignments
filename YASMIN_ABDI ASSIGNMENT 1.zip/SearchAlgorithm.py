import matplotlib.pyplot as plt
import networkx as nx
from queue import Queue, LifoQueue
import heapq
import tracemalloc

# Simplified Maze Layout for Testing (Clear Path)
maze = [
    [0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 1, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0],
    [1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 0],
    [1, 1, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 0, 1, 0, 0, 0, 0, 0, 0],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 1],
    [1, 0, 1, 1, 1, 1, 1, 1, 1, 0, 1, 1, 0, 1, 1, 1, 1, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 1, 0, 1, 1, 0, 0, 0, 1, 0, 1],
    [1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 1],
    [1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 1]
]

# Start and end positions
start = (0, 1)
end = (9, 18)

# Create a graph
G = nx.Graph()

# Add nodes for each free space (0)
for i in range(10):
    for j in range(20):
        if maze[i][j] == 0:
            G.add_node((i, j))

# Add edges between adjacent free spaces
for i in range(10):
    for j in range(20):
        if maze[i][j] == 0:
            for di, dj in [(-1, 0), (1, 0), (0, -1), (0, 1)]:
                ni, nj = i + di, j + dj
                if 0 <= ni < 10 and 0 <= nj < 20 and maze[ni][nj] == 0:
                    G.add_edge((i, j), (ni, nj))

# Define positions for nodes
pos = {(i, j): (j, -i) for i, j in G.nodes}

# BFS implementation
def bfs(maze, start, end):
    queue = Queue()
    queue.put((start, [start]))
    visited = set([start])

    while not queue.empty():
        current, path = queue.get()
        if current == end:
            return path
        for neighbor in G.neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                queue.put((neighbor, path + [neighbor]))
    return None

# DFS implementation
def dfs(maze, start, end):
    stack = LifoQueue()
    stack.put((start, [start]))
    visited = set([start])

    while not stack.empty():
        current, path = stack.get()
        if current == end:
            return path
        for neighbor in G.neighbors(current):
            if neighbor not in visited:
                visited.add(neighbor)
                stack.put((neighbor, path + [neighbor]))
    return None

# A* Search implementation
def heuristic(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])

def a_star(maze, start, end):
    open_list = []
    heapq.heappush(open_list, (0, start, [start]))
    g_costs = {start: 0}
    visited = set([start])

    while open_list:
        _, current, path = heapq.heappop(open_list)

        if current == end:
            return path

        for neighbor in G.neighbors(current):
            tentative_g_cost = g_costs[current] + 1
            if neighbor not in g_costs or tentative_g_cost < g_costs[neighbor]:
                g_costs[neighbor] = tentative_g_cost
                f_cost = tentative_g_cost + heuristic(neighbor, end)
                heapq.heappush(open_list, (f_cost, neighbor, path + [neighbor]))
                visited.add(neighbor)

    return None

# Visualize the path on the graph
def visualize_path(path, algorithm_name):
    plt.figure(figsize=(12, 8))
    nx.draw(G, pos, with_labels=False, node_size=300, node_color='black')
    nx.draw_networkx_nodes(G, pos, nodelist=[start], node_color='red', node_size=300)
    nx.draw_networkx_nodes(G, pos, nodelist=[end], node_color='blue', node_size=300)

    # Highlight path with asterisks
    if path:
        path_edges = list(zip(path, path[1:]))
        nx.draw_networkx_edges(G, pos, edgelist=path_edges, width=2, edge_color='green')
        nx.draw_networkx_nodes(G, pos, nodelist=path, node_color='yellow', node_size=300)
        for i, j in path:
            pos_text = (j, -i)
            plt.text(pos_text[0], pos_text[1], '*', fontsize=12, ha='center', va='center', color='red')

    plt.title(f"Maze Graph - {algorithm_name} Path", fontsize=14)
    plt.axis('equal')
    plt.show()

# Compare algorithms
def compare_algorithms():
    algorithms = {
        "BFS": bfs,
        "DFS": dfs,
        "A*": a_star
    }
    shortest_path = None
    shortest_name = ""
    results = []

    for name, algorithm in algorithms.items():
        tracemalloc.start()
        path = algorithm(maze, start, end)
        current, peak = tracemalloc.get_traced_memory()
        tracemalloc.stop()

        if path:
            path_length = len(path)
            is_optimal = (shortest_path is None or path_length < len(shortest_path))
            results.append((name, path_length, peak, is_optimal))
            if is_optimal:
                shortest_path = path
                shortest_name = name

    for name, path_length, memory, is_optimal in results:
        print(f"Algorithm: {name}")
        print(f"Path Length: {path_length}")
        print(f"Memory Usage: {memory / 1024:.2f} KB")
        print(f"Optimal Path: {'Yes' if is_optimal else 'No'}\n")

    print(f"The algorithm with the shortest path is: {shortest_name}")

# Find paths using BFS, DFS, and A*
path_bfs = bfs(maze, start, end)
path_dfs = dfs(maze, start, end)
path_a_star = a_star(maze, start, end)

# Visualize the paths
visualize_path(path_bfs, "BFS")
visualize_path(path_dfs, "DFS")
visualize_path(path_a_star, "A*")

# Compare and print results
compare_algorithms()